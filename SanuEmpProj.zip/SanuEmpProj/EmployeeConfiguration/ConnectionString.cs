﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeConfiguration
{
    public class ConnectionString
    {
        public string EmployeeDb{ get; set; }
    }
}
