﻿$(document).ready(function () {
    bindEvents();
    hideEmployeeDetailCard();
});

function bindEvents() {
    $(".employeeDetails").on("click", function (event) {
        var employeeId = event.currentTarget.getAttribute("data-id");

        $.ajax({
            url: 'https://localhost:44383/getemployees/' + employeeId,
            type: 'GET',
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                var newEmployeeCard = `<div class="card">
                                          <h1>${result.name}</h1>
                                         <b>Id :</b> <p>${result.id}</p>
                                         <b>Department:</b><p>${result.department}</p>
                                         <b>Age:</b><p>${result.age}</p>
                                         <b>Address:</b><p>${result.address}</p>
                                        </div>`

                $("#EmployeeCard").html(newEmployeeCard);
                showEmployeeDetailCard();
            },
            error: function (error) {
                console.log(error);
            }
        });
    });


    $("#createform").submit(function (event) {
        var employeeDetailedViewModel = {};

        employeeDetailedViewModel.Name = $("#name").val();
        employeeDetailedViewModel.Department = $("#department").val();
        employeeDetailedViewModel.Age = Number($("#age").val());
        employeeDetailedViewModel.Address = $("#address").val();

        var data = JSON.stringify(employeeDetailedViewModel);

        $.ajax({
            url: 'https://localhost:44383/getemployees',
            type: 'POST',
            dataType: "application/json; charset=utf-8",
            contentType: "application/json; charset=utf-8",
            data: data,
            success: function (result) {
                location.reload();
            },
            error: function (error) {
                console.log(error);
            }
        });
        alert("Inserted succesfully");
    });

    //update
    $(".employeeEdit").on("click", function (event) {
        var employeeId = event.currentTarget.getAttribute("data-id");
        $.ajax({
            url: 'https://localhost:44383/getemployees/' + employeeId,
            type: 'GET',
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                $("#updatename").val(result.name)
                $("#updatedepartment").val(result.department)
                $("#updateage").val(result.age)
                $("#updateaddress").val(result.address)
            },
            error: function (error) {
                console.log(error);
            }
        });


        $("#updateform").submit(function (event) {
            var employeeDetailedViewModel = {};

            employeeDetailedViewModel.Name = $("#updatename").val();
            employeeDetailedViewModel.Department = $("#updatedepartment").val();
            employeeDetailedViewModel.Age = Number($("#updateage").val());
            employeeDetailedViewModel.Address = $("#updateaddress").val();

            var data = JSON.stringify(employeeDetailedViewModel);

            $.ajax({
                url: 'https://localhost:44383/getemployees/' + employeeId,
                type: 'PUT',
                dataType: "application/json; charset=utf-8",
                contentType: "application/json; charset=utf-8",
                data: data,
                success: function (result) {
                    location.reload();
                },
                error: function (error) {
                    console.log(error);
                }
            });           
            alert("Updated succesfully");
        });     
    });

 
    $(".employeeDelete").on("click", function (event) {

        var employeeId = event.currentTarget.getAttribute("data-id");

        var confirmdelete = confirm("CONFIRM DELETE");

        if (confirmdelete) {
            $.ajax({
                url: 'https://localhost:44383/getemployees/' + employeeId,
                type: 'DELETE',
                contentType: "application/json; charset=utf-8",
                success: function (result) {
                    location.reload();
                },
                error: function (error){               
                    console.log(error);
                }
            });
            alert("DELETE SUCESSFULLY");
        }
    });


}
function hideEmployeeDetailCard() {
    $("#EmployeeCard").hide();
}

function showEmployeeDetailCard() {
    $("#EmployeeCard").show();
}