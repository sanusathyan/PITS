﻿using EmployeeManagement.UI.Models;
using EmployeeManagement.UI.Models.Provider;
using EmployeeManagement.UI.Providers.Contracts;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace EmployeeManagement.UI.Providers.ApiClients
{
    public class EmployeeApiClient : IEmployeeApiClient
    {
        private readonly HttpClient _httpClient;

        public EmployeeApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

       

        public IEnumerable<EmployeeViewModel> GetAllEmployee()
        {
            var response = _httpClient.GetAsync("https://localhost:44305/api/employees").Result;
            var employeeResponse = response.Content.ReadAsStringAsync().Result;
            var employee = JsonConvert.DeserializeObject<IEnumerable<EmployeeViewModel>>(employeeResponse);
            return employee;
        }

        public EmployeeDetailedViewModel GetEmployeeById(int id)
        {
            var url = $"https://localhost:44305/api/employees/{id}";
            var response = _httpClient.GetAsync(url).Result;
            var employeeResponse = response.Content.ReadAsStringAsync().Result;
            var employee = JsonConvert.DeserializeObject<EmployeeDetailedViewModel>(employeeResponse);
            return employee;
        }

        public bool InsertEmployee(EmployeeDetailedViewModel employeeDetailedViewModel)
        {
            var stringContent = new StringContent(JsonConvert.SerializeObject(employeeDetailedViewModel), Encoding.UTF8, "application/json");
            var response = _httpClient.PostAsync("https://localhost:44305/api/employees", stringContent).Result;
            return true;
        }
        
        public bool UpdateEmployee(EmployeeDetailedViewModel employeeDetailedViewModel)
        {
            var stringContent = new StringContent(JsonConvert.SerializeObject(employeeDetailedViewModel), Encoding.UTF8, "application/json");
            var response = _httpClient.PutAsync("https://localhost:44305/api/employees", stringContent).Result;
            return true;
        }
        public bool DeleteEmployee(int id)
        {
            var stringContent = new StringContent(JsonConvert.SerializeObject(id));
            var response = _httpClient.DeleteAsync($"https://localhost:44305/api/employees/{id}").Result;
            return true;
        }
    }
}
