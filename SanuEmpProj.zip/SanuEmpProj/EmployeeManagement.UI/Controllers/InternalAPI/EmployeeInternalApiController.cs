﻿using EmployeeManagement.DataAccess.Models;
using EmployeeManagement.UI.Models;
using EmployeeManagement.UI.Providers.Contracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.UI.Controllers.InternalAPI
{
    [Route("getemployees")]
    [ApiController]
    public class EmployeeInternalApiController : ControllerBase
    {
        private readonly IEmployeeApiClient _employeeApiClient;

        public EmployeeInternalApiController(IEmployeeApiClient employeeApiClient)
        {
            _employeeApiClient = employeeApiClient;
        }

        [HttpGet]
        [Route("{employeeId}")]
        public IActionResult GetEmployeeById([FromRoute] int employeeId)
        {
            try
            {
                var employee = _employeeApiClient.GetEmployeeById(employeeId);
                return Ok(employee);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        public bool InsertEmployee([FromBody] EmployeeData employeeData)
        {
            try
            {
                var insertEmployee = _employeeApiClient.InsertEmployee(MaptoInsert(employeeData));
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private EmployeeDetailedViewModel MaptoInsert(EmployeeData employeeData)
        {
            var employee = new EmployeeDetailedViewModel
            {
                Id = employeeData.Id,
                Name = employeeData.Name,
                Department = employeeData.Department,
                Age = employeeData.Age,
                Address = employeeData.Address
            };
            return employee;
        }

        [HttpPut]
        [Route("{id}")]
        public IActionResult UpdateEmployee([FromRoute] int id, [FromBody] EmployeeData employeeData)
        {
            try
            {
                employeeData.Id = id;
                var updateEmployee = _employeeApiClient.UpdateEmployee(MaptoUpdate(employeeData));
                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private EmployeeDetailedViewModel MaptoUpdate(EmployeeData employeeData)
        {
            var employee = new EmployeeDetailedViewModel
            {
                Id = employeeData.Id,
                Name = employeeData.Name,
                Department = employeeData.Department,
                Age = employeeData.Age,
                Address = employeeData.Address
            };
            return employee;
        }

        [HttpDelete]
        [Route("{id}")]
        public IActionResult DeleteEmployee([FromRoute] int id)
        {
            try
            {
                var deletEmployee = _employeeApiClient.DeleteEmployee(id);
                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
