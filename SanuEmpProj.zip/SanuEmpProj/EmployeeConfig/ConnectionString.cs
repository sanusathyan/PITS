﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeConfig
{
    public class connectionStrings
    {
        public string employee { get; set; }
    }
}
