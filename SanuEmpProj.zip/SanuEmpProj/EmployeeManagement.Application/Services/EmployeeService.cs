﻿using EmployeeManagement.Application.Contracts;
using EmployeeManagement.Application.Models;
using EmployeeManagement.DataAccess.Contracts;
using EmployeeManagement.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeManagement.Application.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeService(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        public EmployeeDto GetEmployeeById(int id)
        {
            var EmployeeData = _employeeRepository.GetEmployeeById(id);
            if (EmployeeData == null)
            {
                return null;
            }
            return MapEmployeeByID(EmployeeData);
        }

        private EmployeeDto MapEmployeeByID(DataAccess.Models.EmployeeData employeeData)
        {
            var Employee = new EmployeeDto
            {
                Id = employeeData.Id,
                Name = employeeData.Name,
                Department = employeeData.Department,
                Age = employeeData.Age,
                Address = employeeData.Address,
            };
            return Employee;
        }

        public IEnumerable<EmployeeDto> GetEmployees()
        {
            var EmployeeData = _employeeRepository.GetEmployees();
            var ListOfEmployee = EmployeeData.Select(EmployeeData => new EmployeeDto
            {
                Id = EmployeeData.Id,
                Name = EmployeeData.Name,
                Department = EmployeeData.Department,
                Age = EmployeeData.Age,
                Address = EmployeeData.Address
            });
            return ListOfEmployee;
        }

        public bool InsertEmployee(EmployeeDto employeeDto)
        {
            var employee = _employeeRepository.InsertEmployee(MappingEmployee(employeeDto));
            return employee;
        }

        public bool UpdateEmployee(EmployeeDto employeeDto)
        {
            var EditEmployee = _employeeRepository.UpdateEmployee(MappingEmployee(employeeDto));
            return EditEmployee;
        }

        private EmployeeData MappingEmployee(EmployeeDto employeeDto)
        {
            var employee = new EmployeeData
            { 
                Id = employeeDto.Id,
                Name = employeeDto.Name,
                Department = employeeDto.Department,
                Age = employeeDto.Age,
                Address = employeeDto.Address,
            };
            
            return employee;
        }

        public bool DeleteEmployee(int id)
        {
            var deleteEmployee = _employeeRepository.DeleteEmployee(id);
            return deleteEmployee;
        }
    }
}
