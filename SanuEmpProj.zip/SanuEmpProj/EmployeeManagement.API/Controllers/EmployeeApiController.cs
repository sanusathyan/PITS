﻿using EmployeeManagement.API.Models;
using EmployeeManagement.Application.Contracts;
using EmployeeManagement.Application.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeManagement.API.Controllers
{
    [Route("api/employees")]
    [ApiController]
    public class EmployeeApiController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;

        public EmployeeApiController(IEmployeeService employeeService)
        {
            this._employeeService = employeeService;
        }

        [HttpGet]
        [Route("{employeeId}")]
        public IActionResult GetEmployeeById([FromRoute] int employeeId)
        {
            try
            {
                var employeeById = _employeeService.GetEmployeeById(employeeId);
                return Ok(employeeById);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpGet]
        public IActionResult GetEmployees()
        {
            var employee = _employeeService.GetEmployees();
            var EmployeedetailedViewModel = employee.Select(employee => new EmployeeDetailedViewModel
            {
                Id = employee.Id,
                Name = employee.Name,
                Department = employee.Department,
                Age = employee.Age,
                Address = employee.Address
            });
            return Ok(EmployeedetailedViewModel);
        }

        [HttpPost]
        public IActionResult InsertEmployee([FromBody] EmployeeDetailedViewModel employeeDetailedViewModel)
        {
            var InsertEmployee = _employeeService.InsertEmployee(MapInsertEmployee(employeeDetailedViewModel));
            return Ok(InsertEmployee);
        }

        private Application.Models.EmployeeDto MapInsertEmployee(EmployeeDetailedViewModel employeeDetailedViewModel)
        {

            try
            {
                var employee = new EmployeeDto
                {
                    Id = employeeDetailedViewModel.Id,
                    Name = employeeDetailedViewModel.Name,
                    Department = employeeDetailedViewModel.Department,
                    Age = employeeDetailedViewModel.Age,
                    Address = employeeDetailedViewModel.Address,
                };
                return employee;
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPut]
        
        public IActionResult UpdateEmployee( [FromBody] EmployeeDetailedViewModel employeeDetailedViewModel)
        {
            try
            {
                    var updateEmployee = _employeeService.UpdateEmployee(MapUpdateEmployee(employeeDetailedViewModel));
                    return StatusCode(StatusCodes.Status200OK);                              
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        private EmployeeDto MapUpdateEmployee(EmployeeDetailedViewModel employeeDetailedViewModel)
        {
            var employee = new EmployeeDto
            {
                Id = employeeDetailedViewModel.Id,
                Name = employeeDetailedViewModel.Name,
                Department = employeeDetailedViewModel.Department,
                Age = employeeDetailedViewModel.Age,
                Address = employeeDetailedViewModel.Address,
            };
            return employee;
        }

        [HttpDelete]
        [Route("{id}")]
        public IActionResult DeleteEmployee([FromRoute] int id)
        {
            try
            {
                var deleteEmployee = _employeeService.DeleteEmployee(id);
                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
