﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmpConfiguration
{
    public class ConnectionString
    {
        public string EmployeestaffDb { get; set; }
    }
}
