﻿using EmployeeConfiguration;
using EmployeeManagement.DataAccess.Contracts;
using EmployeeManagement.DataAccess.Models;
using Microsoft.Extensions.Options;

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace EmployeeManagement.DataAccess.Repository
{
    /// <summary>
    /// Connect To Database and Perforum CRUD operations
    /// </summary>
    /// </summary>
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly SqlConnection sqlConnection;
        
        
        public EmployeeRepository(IOptions<ConnectionString> connectionStringOption)
        {
            var connectionString = connectionStringOption.Value;

            sqlConnection = new SqlConnection(connectionString.EmployeeDb);
        }

        public EmployeeData GetEmployeeById(int id)
        {
            try
            {
                sqlConnection.Open();

                var sqlCommand = new SqlCommand("SELECT * FROM EMPLOYEE WHERE Id=@id", sqlConnection);

                sqlCommand.Parameters.AddWithValue("id", id);

                var sqlDataRead = sqlCommand.ExecuteReader();

                var employeeList = new List<EmployeeData>();

                while (sqlDataRead.Read())
                {
                    employeeList.Add(new EmployeeData
                    {
                        Id = (int)sqlDataRead["Id"],
                        Name = (string)sqlDataRead["Ename"],
                        Department = (string)sqlDataRead["Department"],
                        Age = (int)sqlDataRead["Age"],
                        Address = (string)sqlDataRead["Eaddress"],
                    });
                }
                return employeeList.FirstOrDefault();
            }
            catch
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        public IEnumerable<EmployeeData> GetEmployees()
        {
            try
            {
                sqlConnection.Open();

                var sqlCommand = new SqlCommand("select * from employee", sqlConnection);

                var sqlDataRead = sqlCommand.ExecuteReader();

                var employeeList = new List<EmployeeData>();

                while (sqlDataRead.Read())
                {
                    employeeList.Add(new EmployeeData
                    {
                        Id = (int)sqlDataRead["Id"],
                        Name = (string)sqlDataRead["Ename"],
                        Department = (string)sqlDataRead["Department"],
                        Age = (int)sqlDataRead["Age"],
                        Address = (string)sqlDataRead["Eaddress"],
                    });
                }
                return employeeList;
            }

            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        public bool InsertEmployee(EmployeeData employeeData)
        {
            try
            {
                sqlConnection.Open();

                var sqlCommand = new SqlCommand("insert into employee values(@Name,@Department,@Age,@Address)", sqlConnection);

                sqlCommand.Parameters.AddWithValue("Name", employeeData.Name);
                sqlCommand.Parameters.AddWithValue("Department", employeeData.Department);
                sqlCommand.Parameters.AddWithValue("Age", employeeData.Age);
                sqlCommand.Parameters.AddWithValue("Address", employeeData.Address);

                sqlCommand.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        public bool UpdateEmployee(EmployeeData employeeData)
        {
            try
            {
                sqlConnection.Open();
                var sqlCommand = new SqlCommand("update employee set Ename= @name, Department = @department,Age=@age,Eaddress=@address where Id=@id", sqlConnection);
                sqlCommand.Parameters.AddWithValue("name", employeeData.Name);
                sqlCommand.Parameters.AddWithValue("department", employeeData.Department);
                sqlCommand.Parameters.AddWithValue("age", employeeData.Age);
                sqlCommand.Parameters.AddWithValue("address", employeeData.Address);
                sqlCommand.Parameters.AddWithValue("id", employeeData.Id);
                sqlCommand.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        public bool DeleteEmployee(int id)
        {
            try
            {
                sqlConnection.Open();
                var sqlCommand = new SqlCommand("delete from employee where Id = @id", sqlConnection);
                sqlCommand.Parameters.AddWithValue("id", id);
                sqlCommand.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }
        }
    }

}
//Create Methods For Table insert, update and Delete Here


